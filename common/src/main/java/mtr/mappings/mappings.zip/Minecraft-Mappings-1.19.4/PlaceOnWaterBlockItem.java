package @package@;

import net.minecraft.world.level.block.Block;

public class PlaceOnWaterBlockItem extends net.minecraft.world.item.PlaceOnWaterBlockItem {

	public PlaceOnWaterBlockItem(Block block, Properties properties) {
		super(block, properties);
	}
}
