package @package@;

import net.minecraft.client.gui.components.Renderable;

public interface WidgetMapper extends Renderable {
}
